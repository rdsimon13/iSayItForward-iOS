//
//  ManageSIFView.swift
//  iSayItForward
//
//  Created by Reginald Simon on 10/17/25.
//

import Foundation
