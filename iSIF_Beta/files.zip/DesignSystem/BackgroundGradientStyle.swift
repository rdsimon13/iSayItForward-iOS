enum BackgroundStyle {
    case signIn
    case signUp
    case standard
}
