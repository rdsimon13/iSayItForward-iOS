//import Foundation

//enum TemplateCategory: String, CaseIterable, Codable {
 //   case encouragement = "Encouragement"
  //  case holiday = "Holiday"
  //  case announcement = "Announcement"
  //  case sympathy = "Sympathy"
    // Add others as needed
//}

//struct TemplateItem: Identifiable, Codable {
   // let id: UUID
   //// let name: String
  //  let message: String
  //  let imageName: String
  //  let category: TemplateCategory
//}
//


