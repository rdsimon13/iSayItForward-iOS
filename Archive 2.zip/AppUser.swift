// ✅ AppUser model
struct AppUser {
    let uid: String
    let name: String
    let email: String
}
